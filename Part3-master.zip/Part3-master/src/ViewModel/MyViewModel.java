package ViewModel;

public class MyViewModel {
}
