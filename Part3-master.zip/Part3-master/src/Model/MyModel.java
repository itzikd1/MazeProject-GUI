package Model;

public class MyModel implements IModel {
}
