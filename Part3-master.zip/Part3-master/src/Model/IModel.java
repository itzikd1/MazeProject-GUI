package Model;

public interface IModel {
}
