package View;

public interface IView {
}
