package View;

public class MyViewController implements IView {
}
